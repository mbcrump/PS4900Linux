poc

send elf using send_elf.py
once sent, if successful it will listen on port 9030 and will dump the kernel data
me very lazy, explanation skills D-

FAQ
---

Q: HEN?
A: No
