package org.homebrew;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class HttpClient {
	
	 protected URL url;
	  protected HttpURLConnection server;

	  /**
	   * @param szUrl: String object for the URL
	   */
	  public HttpClient(String szUrl) throws Exception
	  {
	    try
	    {
	      url = new URL(szUrl);
	    }
	    catch (Exception e)
	    {
	      throw new Exception("Invalid URL");
	    }
	  }

	  /**
	   * @param method: String object for client method (POST, GET,...)
	   */
	  public void connect(String method) throws Exception
	  {
	    try
	    {
	      server = (HttpURLConnection)url.openConnection();
	      server.setDoInput(true);
	      server.setDoOutput(true);
	      server.setRequestMethod(method);
	      server.setRequestProperty("Content-type",
	                                "application/x-www-form-urlencoded");
	      server.connect();
	    }
	    catch (Exception e)
	    {
	      throw new Exception("Connection failed");
	    }
	  }

	  public void disconnect()
	  {
	    server.disconnect();
	  }

	  public ArrayList getResponse() throws Exception
	  {
		  ArrayList text = new ArrayList();

	    try
	    {
	      BufferedReader s = new BufferedReader(
	                            new InputStreamReader(
	                                server.getInputStream()));
	     String  line = s.readLine();
	      while (line != null)
	      {
	        
	    	  text.add(line);
	    	  line = s.readLine();
	      }
	      s.close();
	    }
	    catch(Exception e)
	    {
	      throw new Exception("Unable to read input stream");
	    }
	    
	    return text;
	  }

	  public void post(String s) throws Exception
	  {
	    try
	    {
	      BufferedWriter bw = new BufferedWriter(
	                                new OutputStreamWriter(
	                                    server.getOutputStream()));
	      bw.write(s, 0, s.length());
	      bw.flush();
	      bw.close();
	    }
	    catch(Exception e)
	    {
	      throw new Exception("Unable to write to output stream");
	    }

	  }

}
