BD-J for PS3 minimal devkit by FreePlay

NOTE: For this to work properly, you *MUST* copy it to the root of your C: drive - that is, to C:\bdj-ps3. DO NOT rename the folder.

Included is everything you'll need to get started except for:
1. a working installation of JDK, the Java Development Kit (get that from http://java.sun.com/javase/downloads/index.jsp - currently, the latest version is JDK 6 Update 7)
2. a copy of bdj.jar, the BD-J API. I can't provide this, since you need a license to use it; however, if you have a PC program capable of making or playing Blu-Ray discs - like Nero or PowerDVD - you can get this file from there. (In Nero 8, the file is located in C:\program Files\Common Files\Nero\NeroBLC\BDJ\jlib .)

I don't have any real documentation on BD-J, though I'm sure you can find some on the HDCookBook website. In the 'docs' folder is some basic info on BD-J on a very high level.

So far as I can tell, there are some pretty strict limitations on the PS3's implementation of BD-J:
1. You cannot read or write local files.
2. You cannot list the contents of a directory.

I may be wrong, so feel free to correct me, but I ran a few tests and couldn't do those things.

I've also included a sample Hello World application and silenoz's RSS reader, as well as a build.bat file for building, packing, and signing the programs. This batch script is pretty much universal, unless you need to add in other JAR files for your compilation.

Source files for each project should go in a folder called root\org\homebrew. For example, if you make a project called "Test App", in your "Test App" folder you'll place the universal build.bat , then make a root\org\homebrew folder and place your .java files in there. The 'root' folder will become the root of your JAR file; any files you place in that structure will become part of the JAR.

The 'disc files' folder contains the file structure for what you'll copy to your storage device. Once you've built your 00000.jar file, copy it to 'AVCHD\BDMV\JAR\' and you'll be ready to test it.

Good luck!